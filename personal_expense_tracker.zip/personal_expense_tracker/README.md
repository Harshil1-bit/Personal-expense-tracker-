# Personal Expense Tracker

A simple command-line Python application to record and review personal expenses.

## Features
- Add an expense with date, name, category, and amount
- View all saved expenses
- Calculate total spending
- Summarize spending by category
- Search expenses by name

## Requirements
- Python 3
- No external packages required (`csv` and `os` are built-in Python modules)

## Run
Open a terminal in this folder and execute:

    python expense_tracker.py

The program automatically creates `expenses.csv` the first time it runs. Your expense records are saved there and remain available when you run the program again.
