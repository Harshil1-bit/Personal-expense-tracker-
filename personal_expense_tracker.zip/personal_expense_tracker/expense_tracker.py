import csv
import os

file_name = "expenses.csv"

def initialize_file():
    if not os.path.exists(file_name):
        with open(file_name, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Date", "Expense", "Category", "Amount"])


def read_expenses():
    expenses = []

    with open(file_name, "r", newline="") as file:
        reader = csv.reader(file)
        next(reader, None)

        for row in reader:
            if len(row) == 4:
                expenses.append(row)

    return expenses


def add_expense():
    date = input("Enter date (YYYY-MM-DD): ").strip()
    name = input("Enter expense name: ").strip()
    category = input("Enter category: ").strip().title()

    if date == "" or name == "" or category == "":
        print("Please fill in all the details.")
        return

    try:
        amount = float(input("Enter amount: "))
    except ValueError:
        print("Please enter a valid amount.")
        return

    if amount <= 0:
        print("Amount must be greater than zero.")
        return

    with open(file_name, "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([date, name, category, amount])

    print("Expense added successfully.")


def view_expenses():
    expenses = read_expenses()

    if len(expenses) == 0:
        print("No expenses recorded yet.")
        return

    print("\nDate         Expense              Category          Amount")
    print("-" * 65)

    for row in expenses:
        print(f"{row[0]:12} {row[1]:20} {row[2]:17} Rs. {float(row[3]):.2f}")


def total_spending():
    expenses = read_expenses()
    total = 0

    for row in expenses:
        total = total + float(row[3])

    print(f"Total spending: Rs. {total:.2f}")


def category_summary():
    expenses = read_expenses()
    category_totals = {}

    for row in expenses:
        category = row[2]
        amount = float(row[3])

        if category in category_totals:
            category_totals[category] = category_totals[category] + amount
        else:
            category_totals[category] = amount

    if len(category_totals) == 0:
        print("No expenses recorded yet.")
        return

    print("\nSpending by category:")
    for category, amount in category_totals.items():
        print(f"{category}: Rs. {amount:.2f}")


def search_expenses():
    expenses = read_expenses()
    search_text = input("Enter expense name to search: ").strip().lower()

    if search_text == "":
        print("Please enter an expense name.")
        return

    found = False

    for row in expenses:
        if search_text in row[1].lower():
            print(f"Date: {row[0]} | Expense: {row[1]} | Category: {row[2]} | Amount: Rs. {float(row[3]):.2f}")
            found = True

    if not found:
        print("No matching expenses found.")


def main():
    initialize_file()

    while True:
        print("\n===== PERSONAL EXPENSE TRACKER =====")
        print("1. Add an expense")
        print("2. View all expenses")
        print("3. Calculate total spending")
        print("4. View spending by category")
        print("5. Search expenses")
        print("6. Exit")

        choice = input("Enter your choice: ").strip()

        if choice == "1":
            add_expense()
        elif choice == "2":
            view_expenses()
        elif choice == "3":
            total_spending()
        elif choice == "4":
            category_summary()
        elif choice == "5":
            search_expenses()
        elif choice == "6":
            print("Thank you for using the expense tracker.")
            break
        else:
            print("Invalid choice. Please select from 1 to 6.")


main()
